from django.apps import AppConfig


class KiberSecurityConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kiber_security'
